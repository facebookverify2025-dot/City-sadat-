const Database = {
  async getRegions() {
    try {
      console.log('Loading regions...');
      const result = await trickleListObjects('region', 100, true);
      console.log('Regions loaded:', result.items.length);
      return result.items || [];
    } catch (error) {
      console.error('Get regions error:', error);
      return [];
    }
  },

  async createRegion(name) {
    try {
      console.log('Creating region:', name);
      const result = await trickleCreateObject('region', { name, createdAt: new Date().toISOString() });
      console.log('Region created successfully:', result);
      return result;
    } catch (error) {
      console.error('Create region error:', error);
      throw error;
    }
  },

  async updateRegion(objectId, regionData) {
    try {
      console.log('Updating region:', objectId, regionData);
      const result = await trickleUpdateObject('region', objectId, regionData);
      console.log('Region updated successfully:', result);
      return result;
    } catch (error) {
      console.error('Update region error:', error);
      console.error('Update details:', {
        objectId,
        regionData,
        errorMessage: error.message
      });
      throw new Error(`فشل في حفظ الخريطة: ${error.message}`);
    }
  },

  async getProperties() {
    try {
      console.log('Loading properties...');
      const result = await trickleListObjects('property', 100, true);
      console.log('Properties loaded:', result.items.length);
      return result.items || [];
    } catch (error) {
      console.error('Get properties error:', error);
      return [];
    }
  },

  async createProperty(propertyData) {
    try {
      console.log('Creating property:', propertyData.title);
      const result = await trickleCreateObject('property', { ...propertyData, createdAt: new Date().toISOString() });
      console.log('Property created successfully:', result);
      return result;
    } catch (error) {
      console.error('Create property error:', error);
      throw error;
    }
  },

  async updateProperty(objectId, propertyData) {
    try {
      console.log('Updating property:', objectId);
      const result = await trickleUpdateObject('property', objectId, propertyData);
      console.log('Property updated successfully:', result);
      return result;
    } catch (error) {
      console.error('Update property error:', error);
      throw error;
    }
  },

  async getSettings() {
    try {
      const result = await trickleListObjects('settings', 1, true);
      if (result.items && result.items.length > 0) {
        return result.items[0];
      }
      const defaultSettings = {
        companyEmail: 'info@general.com',
        whatsappNumber: '+201034551612',
        facebookUrl: '',
        instagramUrl: '',
        heroImageUrl: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80'
      };
      return await trickleCreateObject('settings', defaultSettings);
    } catch (error) {
      console.error('Get settings error:', error);
      return { objectId: null, objectData: {} };
    }
  },

  async updateSettings(objectId, settingsData) {
    try {
      return await trickleUpdateObject('settings', objectId, settingsData);
    } catch (error) {
      console.error('Update settings error:', error);
      throw error;
    }
  },

  async createMessage(messageData) {
    try {
      return await trickleCreateObject('message', { ...messageData, createdAt: new Date().toISOString(), read: false });
    } catch (error) {
      console.error('Create message error:', error);
      throw error;
    }
  },

  async getMessages() {
    try {
      const result = await trickleListObjects('message', 100, true);
      return result.items || [];
    } catch (error) {
      console.error('Get messages error:', error);
      return [];
    }
  },

  async deleteProperty(objectId) {
    try {
      return await trickleDeleteObject('property', objectId);
    } catch (error) {
      console.error('Delete property error:', error);
      throw error;
    }
  },

  async deleteRegion(objectId) {
    try {
      return await trickleDeleteObject('region', objectId);
    } catch (error) {
      console.error('Delete region error:', error);
      throw error;
    }
  }
};
