// Trickle Database Implementation with Real-time Updates
const trickleDB = {
  // Real-time configuration
  realtimeConfig: {
    enabled: true,
    serverUrl: (window.location.protocol === 'https:' ? 'https://forest-champion-stopped-map.trycloudflare.com' : 'http://localhost:8090'),
    reconnectInterval: 5000,
    maxReconnectAttempts: 10
  },
  
  // Real-time state
  realtimeState: {
    connected: false,
    reconnectAttempts: 0,
    eventSource: null,
    onUpdateCallbacks: new Map()
  },

  // Initialize database structure
  init() {
    if (!localStorage.getItem('trickle_regions')) {
      localStorage.setItem('trickle_regions', JSON.stringify([]));
    }
    if (!localStorage.getItem('trickle_properties')) {
      localStorage.setItem('trickle_properties', JSON.stringify([]));
    }
    if (!localStorage.getItem('trickle_settings')) {
      localStorage.setItem('trickle_settings', JSON.stringify([]));
    }
    if (!localStorage.getItem('trickle_messages')) {
      localStorage.setItem('trickle_messages', JSON.stringify([]));
    }
    
    // Initialize real-time connection
    if (this.realtimeConfig.enabled) {
      this.initRealTime();
    }
  },

  // Initialize real-time connection
  initRealTime() {
    try {
      const eventSource = new EventSource(`${this.realtimeConfig.serverUrl}/events`);
      
      eventSource.onopen = () => {
        console.log('🔗 Real-time connection established');
        this.realtimeState.connected = true;
        this.realtimeState.reconnectAttempts = 0;
        this.triggerEvent('connection', { status: 'connected' });
      };
      
      eventSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          this.handleRealTimeEvent(data);
        } catch (error) {
          console.error('Error parsing real-time event:', error);
        }
      };
      
      eventSource.addEventListener('update', (event) => {
        try {
          const data = JSON.parse(event.data);
          this.handleRealTimeEvent(data);
        } catch (error) {
          console.error('Error parsing update event:', error);
        }
      });
      
      eventSource.onerror = (error) => {
        console.error('❌ Real-time connection error:', error);
        this.realtimeState.connected = false;
        this.triggerEvent('connection', { status: 'disconnected' });
        this.attemptReconnect();
      };
      
      this.realtimeState.eventSource = eventSource;
      
    } catch (error) {
      console.error('❌ Failed to initialize real-time connection:', error);
      this.attemptReconnect();
    }
  },

  // Attempt to reconnect
  attemptReconnect() {
    if (this.realtimeState.reconnectAttempts < this.realtimeConfig.maxReconnectAttempts) {
      this.realtimeState.reconnectAttempts++;
      console.log(`🔄 Attempting to reconnect... (${this.realtimeState.reconnectAttempts}/${this.realtimeConfig.maxReconnectAttempts})`);
      
      setTimeout(() => {
        this.initRealTime();
      }, this.realtimeConfig.reconnectInterval);
    } else {
      console.error('❌ Max reconnection attempts reached. Real-time updates disabled.');
      this.triggerEvent('connection', { status: 'failed' });
    }
  },

  // Handle real-time events
  handleRealTimeEvent(data) {
    const { type, table, objectId, objectData, action } = data;
    
    console.log('📡 Real-time event received:', { type, table, action });
    
    // Update local data based on event type
    if (action === 'create') {
      this.applyCreateEvent(table, objectId, objectData);
    } else if (action === 'update') {
      this.applyUpdateEvent(table, objectId, objectData);
    } else if (action === 'delete') {
      this.applyDeleteEvent(table, objectId);
    }
    
    // Trigger UI updates
    this.triggerEvent('dataChange', { table, action, objectId });
  },

  // Apply create event
  applyCreateEvent(table, objectId, objectData) {
    try {
      const objects = JSON.parse(localStorage.getItem(`trickle_${table}`) || '[]');
      
      // Check if object already exists
      const exists = objects.find(obj => obj.objectId === objectId);
      if (!exists) {
        const newObject = {
          objectId,
          objectData,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        objects.push(newObject);
        localStorage.setItem(`trickle_${table}`, JSON.stringify(objects));
        console.log('✅ Applied create event:', objectId);
      }
    } catch (error) {
      console.error('Error applying create event:', error);
    }
  },

  // Apply update event
  applyUpdateEvent(table, objectId, objectData) {
    try {
      const objects = JSON.parse(localStorage.getItem(`trickle_${table}`) || '[]');
      const index = objects.findIndex(obj => obj.objectId === objectId);
      
      if (index !== -1) {
        objects[index].objectData = { ...objects[index].objectData, ...objectData };
        objects[index].updatedAt = new Date().toISOString();
        localStorage.setItem(`trickle_${table}`, JSON.stringify(objects));
        console.log('✅ Applied update event:', objectId);
      }
    } catch (error) {
      console.error('Error applying update event:', error);
    }
  },

  // Apply delete event
  applyDeleteEvent(table, objectId) {
    try {
      const objects = JSON.parse(localStorage.getItem(`trickle_${table}`) || '[]');
      const filteredObjects = objects.filter(obj => obj.objectId !== objectId);
      
      if (objects.length !== filteredObjects.length) {
        localStorage.setItem(`trickle_${table}`, JSON.stringify(filteredObjects));
        console.log('✅ Applied delete event:', objectId);
      }
    } catch (error) {
      console.error('Error applying delete event:', error);
    }
  },

  // Broadcast data change
  async broadcastChange(table, action, objectId, objectData) {
    if (!this.realtimeState.connected) {
      console.log('⚠️ Real-time not connected, skipping broadcast');
      return;
    }
    
    try {
      const response = await fetch(`${this.realtimeConfig.serverUrl}/broadcast`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          type: 'data_change',
          table,
          action,
          objectId,
          objectData,
          timestamp: new Date().toISOString()
        })
      });
      
      if (response.ok) {
        console.log('📡 Broadcast successful:', { table, action, objectId });
      } else {
        console.error('❌ Broadcast failed:', response.status);
      }
    } catch (error) {
      console.error('❌ Error broadcasting change:', error);
    }
  },

  // Register event callback
  on(eventName, callback) {
    if (!this.realtimeState.onUpdateCallbacks.has(eventName)) {
      this.realtimeState.onUpdateCallbacks.set(eventName, new Set());
    }
    this.realtimeState.onUpdateCallbacks.get(eventName).add(callback);
  },

  // Unregister event callback
  off(eventName, callback) {
    if (this.realtimeState.onUpdateCallbacks.has(eventName)) {
      this.realtimeState.onUpdateCallbacks.get(eventName).delete(callback);
    }
  },

  // Trigger event
  triggerEvent(eventName, data) {
    if (this.realtimeState.onUpdateCallbacks.has(eventName)) {
      this.realtimeState.onUpdateCallbacks.get(eventName).forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error('Error in event callback:', error);
        }
      });
    }
  },

  // Check real-time status
  getRealTimeStatus() {
    return {
      connected: this.realtimeState.connected,
      reconnectAttempts: this.realtimeState.reconnectAttempts
    };
  },

  // Generate unique ID
  generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  },

  // List objects from a table
  async trickleListObjects(table, limit = 100, includeAll = false) {
    try {
      const data = JSON.parse(localStorage.getItem(`trickle_${table}`) || '[]');
      
      // Add missing objectId and objectData if not present
      const processed = data.map(item => {
        if (!item.objectId) {
          item.objectId = this.generateId();
        }
        if (!item.objectData) {
          item.objectData = {};
        }
        return item;
      });
      
      // Save processed data back
      localStorage.setItem(`trickle_${table}`, JSON.stringify(processed));
      
      return {
        items: processed.slice(0, limit),
        total: processed.length
      };
    } catch (error) {
      console.error(`Error listing ${table}:`, error);
      return { items: [], total: 0 };
    }
  },

  // Create a new object
  async trickleCreateObject(table, data) {
    try {
      const objects = JSON.parse(localStorage.getItem(`trickle_${table}`) || '[]');
      const newObject = {
        objectId: this.generateId(),
        objectData: data,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      objects.push(newObject);
      localStorage.setItem(`trickle_${table}`, JSON.stringify(objects));
      
      // Broadcast real-time update
      await this.broadcastChange(table, 'create', newObject.objectId, newObject.objectData);
      
      // Trigger local UI update
      this.triggerEvent('dataChange', { table, action: 'create', objectId: newObject.objectId, object: newObject });
      
      return newObject;
    } catch (error) {
      console.error(`Error creating ${table} object:`, error);
      throw error;
    }
  },

  // Update an existing object
  async trickleUpdateObject(table, objectId, data) {
    try {
      const objects = JSON.parse(localStorage.getItem(`trickle_${table}`) || '[]');
      const index = objects.findIndex(obj => obj.objectId === objectId);
      
      if (index === -1) {
        throw new Error(`Object with ID ${objectId} not found in ${table}`);
      }
      
      // Store old data for potential rollback
      const oldData = { ...objects[index].objectData };
      
      // Merge the new data with existing data
      objects[index].objectData = { ...objects[index].objectData, ...data };
      objects[index].updatedAt = new Date().toISOString();
      
      localStorage.setItem(`trickle_${table}`, JSON.stringify(objects));
      
      // Broadcast real-time update
      await this.broadcastChange(table, 'update', objectId, objects[index].objectData);
      
      // Trigger local UI update
      this.triggerEvent('dataChange', { table, action: 'update', objectId, object: objects[index], oldData });
      
      return objects[index];
    } catch (error) {
      console.error(`Error updating ${table} object:`, error);
      throw error;
    }
  },

  // Delete an object
  async trickleDeleteObject(table, objectId) {
    try {
      const objects = JSON.parse(localStorage.getItem(`trickle_${table}`) || '[]');
      const objectToDelete = objects.find(obj => obj.objectId === objectId);
      const filteredObjects = objects.filter(obj => obj.objectId !== objectId);
      
      if (objects.length === filteredObjects.length) {
        throw new Error(`Object with ID ${objectId} not found in ${table}`);
      }
      
      localStorage.setItem(`trickle_${table}`, JSON.stringify(filteredObjects));
      
      // Broadcast real-time update
      await this.broadcastChange(table, 'delete', objectId, objectToDelete ? objectToDelete.objectData : null);
      
      // Trigger local UI update
      this.triggerEvent('dataChange', { table, action: 'delete', objectId, object: objectToDelete });
      
      return { success: true };
    } catch (error) {
      console.error(`Error deleting ${table} object:`, error);
      throw error;
    }
  },

  // Clear all data (for development)
  async trickleClearAll() {
    const oldData = {
      regions: JSON.parse(localStorage.getItem('trickle_regions') || '[]'),
      properties: JSON.parse(localStorage.getItem('trickle_properties') || '[]'),
      settings: JSON.parse(localStorage.getItem('trickle_settings') || '[]'),
      messages: JSON.parse(localStorage.getItem('trickle_messages') || '[]')
    };
    
    localStorage.removeItem('trickle_regions');
    localStorage.removeItem('trickle_properties');
    localStorage.removeItem('trickle_settings');
    localStorage.removeItem('trickle_messages');
    this.init();
    
    // Broadcast clear event
    await this.broadcastChange('all', 'clear', 'all', oldData);
    
    // Trigger local UI update
    this.triggerEvent('dataChange', { table: 'all', action: 'clear' });
  }
};

// Initialize database on load
trickleDB.init();

// Export for use in other files
if (typeof window !== 'undefined') {
  window.trickleDB = trickleDB;
  window.trickleListObjects = trickleDB.trickleListObjects.bind(trickleDB);
  window.trickleCreateObject = trickleDB.trickleCreateObject.bind(trickleDB);
  window.trickleUpdateObject = trickleDB.trickleUpdateObject.bind(trickleDB);
  window.trickleDeleteObject = trickleDB.trickleDeleteObject.bind(trickleDB);
  window.trickleClearAll = trickleDB.trickleClearAll.bind(trickleDB);
  
  // Real-time utilities
  window.trickleOnUpdate = trickleDB.on.bind(trickleDB);
  window.trickleOffUpdate = trickleDB.off.bind(trickleDB);
  window.trickleGetRealTimeStatus = trickleDB.getRealTimeStatus.bind(trickleDB);
}