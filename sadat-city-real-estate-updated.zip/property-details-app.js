function PropertyDetailsApp() {
  const [property, setProperty] = React.useState(null);
  const [currentImageIndex, setCurrentImageIndex] = React.useState(0);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    loadProperty();
  }, []);

  const loadProperty = async () => {
    const params = new URLSearchParams(window.location.search);
    const propertyId = params.get('id');
    
    if (!propertyId) {
      window.location.href = 'index.html';
      return;
    }

    try {
      const prop = await trickleGetObject('property', propertyId);
      setProperty(prop);
    } catch (error) {
      console.error('Load property error:', error);
      alert('حدث خطأ في تحميل العقار');
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">جاري التحميل...</div>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">لم يتم العثور على العقار</div>
      </div>
    );
  }

  const data = property.objectData;
  const images = data.images || [];
  const currentImage = images[currentImageIndex] || 'https://images.unsplash.com/photo-1582407947304-fd86f028f716?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80';

  return (
    <div className="min-h-screen bg-[var(--light-bg)]">
      <header className="bg-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <button 
            onClick={() => window.location.href = 'index.html'}
            className="flex items-center gap-2 text-[var(--primary-color)] hover:text-[var(--secondary-color)]">
            <div className="icon-arrow-right text-xl"></div>
            <span className="font-semibold">العودة للرئيسية</span>
          </button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="relative h-96 md:h-[500px] bg-gray-200">
            <img src={currentImage} alt={data.title} className="w-full h-full object-cover" />
            
            {images.length > 1 && (
              <>
                <button 
                  onClick={() => setCurrentImageIndex((currentImageIndex - 1 + images.length) % images.length)}
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-white bg-opacity-80 p-3 rounded-full hover:bg-opacity-100">
                  <div className="icon-chevron-left text-xl"></div>
                </button>
                <button 
                  onClick={() => setCurrentImageIndex((currentImageIndex + 1) % images.length)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-white bg-opacity-80 p-3 rounded-full hover:bg-opacity-100">
                  <div className="icon-chevron-right text-xl"></div>
                </button>
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                  {images.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentImageIndex(idx)}
                      className={`w-2 h-2 rounded-full ${idx === currentImageIndex ? 'bg-white' : 'bg-white bg-opacity-50'}`}
                    />
                  ))}
                </div>
              </>
            )}

            {data.status === 'sold' && (
              <div className="absolute top-4 right-4 bg-red-500 text-white px-4 py-2 rounded-full font-semibold">
                تم البيع
              </div>
            )}
            {data.status === 'available' && (
              <div className="absolute top-4 right-4 bg-green-500 text-white px-4 py-2 rounded-full font-semibold">
                متاح
              </div>
            )}
          </div>

          <div className="p-6 md:p-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">{data.title}</h1>
            
            <div className="flex items-center gap-2 text-gray-600 mb-6">
              <div className="icon-map-pin text-xl text-[var(--primary-color)]"></div>
              <span className="text-lg">{data.region}</span>
            </div>

            <div className="text-4xl font-bold text-[var(--primary-color)] mb-8">
              {data.price} جنيه
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {data.area && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="icon-maximize text-2xl text-[var(--primary-color)] mb-2"></div>
                  <div className="text-sm text-gray-600">المساحة</div>
                  <div className="text-xl font-bold">{data.area} م²</div>
                </div>
              )}
              {data.bedrooms && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="icon-bed text-2xl text-[var(--primary-color)] mb-2"></div>
                  <div className="text-sm text-gray-600">غرف النوم</div>
                  <div className="text-xl font-bold">{data.bedrooms}</div>
                </div>
              )}
              {data.bathrooms && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="icon-bath text-2xl text-[var(--primary-color)] mb-2"></div>
                  <div className="text-sm text-gray-600">الحمامات</div>
                  <div className="text-xl font-bold">{data.bathrooms}</div>
                </div>
              )}
              {data.parking && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="icon-car text-2xl text-[var(--primary-color)] mb-2"></div>
                  <div className="text-sm text-gray-600">المواقف</div>
                  <div className="text-xl font-bold">{data.parking}</div>
                </div>
              )}
            </div>

            <div className="border-t pt-6 mb-6">
              <h2 className="text-2xl font-bold mb-4">المميزات</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3">
                  <div className="icon-home text-xl text-green-600"></div>
                  <span>النوع: {data.type === 'residential' ? 'سكني' : 'تجاري'}</span>
                </div>
                {data.floors && (
                  <div className="flex items-center gap-3">
                    <div className="icon-layers text-xl text-green-600"></div>
                    <span>عدد الطوابق: {data.floors}</span>
                  </div>
                )}
                {data.furnished && (
                  <div className="flex items-center gap-3">
                    <div className="icon-sofa text-xl text-green-600"></div>
                    <span>التأثيث: {data.furnished}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="border-t pt-6">
              <h2 className="text-2xl font-bold mb-4">الوصف</h2>
              <p className="text-lg text-gray-700 leading-relaxed">{data.description}</p>
            </div>

            {data.videos && data.videos.length > 0 && (
              <div className="border-t pt-6 mt-6">
                <h2 className="text-2xl font-bold mb-4">فيديو العقار</h2>
                <video controls className="w-full rounded-lg">
                  <source src={data.videos[0]} type="video/mp4" />
                </video>
              </div>
            )}

            <div className="border-t pt-6 mt-6 flex gap-4">
              <a 
                href="index.html#contact"
                className="flex-1 bg-[var(--primary-color)] text-white py-4 rounded-lg font-bold text-center hover:bg-[var(--secondary-color)] transition-all">
                استفسر الآن
              </a>
              <a 
                href={`https://wa.me/201034551612?text=مرحباً، أنا مهتم بالعقار: ${data.title}`}
                target="_blank"
                className="flex-1 bg-green-600 text-white py-4 rounded-lg font-bold text-center hover:bg-green-700 transition-all flex items-center justify-center gap-2">
                <div className="icon-message-circle text-xl"></div>
                واتساب
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<PropertyDetailsApp />);