function AdminPanel({ onLogin, onNavigate, onUpdate }) {
  try {
    const [password, setPassword] = React.useState('');
    const [isAuthenticated, setIsAuthenticated] = React.useState(false);
    const [activeTab, setActiveTab] = React.useState('regions');
    const ADMIN_PASSWORD = 'General real estate';

    const handleLogin = () => {
      if (password === ADMIN_PASSWORD) {
        setIsAuthenticated(true);
        onLogin(true);
      } else {
        alert('كلمة المرور غير صحيحة');
      }
    };

    if (!isAuthenticated) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100" data-name="admin-login" data-file="components/AdminPanel.js">
          <div className="bg-white p-8 rounded-xl shadow-lg max-w-md w-full">
            <button onClick={() => { window.location.hash = ''; onNavigate('home'); }} className="mb-4 text-gray-600 hover:text-gray-900">
              <div className="icon-arrow-right text-xl"></div>
            </button>
            <h2 className="text-2xl font-bold mb-6 text-center">لوحة الإدارة</h2>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
              placeholder="كلمة المرور"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg mb-4 focus:outline-none focus:border-[var(--primary-color)]"
            />
            <button onClick={handleLogin} className="w-full btn-primary">
              دخول
            </button>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gray-100 py-8" data-name="admin-panel" data-file="components/AdminPanel.js">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">لوحة الإدارة</h2>
              <button onClick={() => { window.location.hash = ''; onNavigate('home'); }} className="px-4 py-2 bg-gray-200 rounded-lg hover:bg-gray-300">
                العودة للرئيسية
              </button>
            </div>
            
            <div className="flex gap-4 mb-6 border-b overflow-x-auto">
              {['regions', 'settings', 'hero', 'messages'].map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-2 font-semibold whitespace-nowrap ${activeTab === tab ? 'border-b-2 border-[var(--primary-color)] text-[var(--primary-color)]' : 'text-gray-600'}`}
                >
                  {tab === 'regions' && 'المناطق والعقارات'}
                  {tab === 'settings' && 'الإعدادات'}
                  {tab === 'hero' && 'صورة الخلفية'}
                  {tab === 'messages' && 'الرسائل'}
                </button>
              ))}
            </div>

            {activeTab === 'regions' && <RegionsManager onUpdate={onUpdate} />}
            {activeTab === 'settings' && <SettingsManager onUpdate={onUpdate} />}
            {activeTab === 'hero' && <HeroImageManager onUpdate={onUpdate} />}
            {activeTab === 'messages' && <MessagesManager />}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('AdminPanel component error:', error);
    return null;
  }
}