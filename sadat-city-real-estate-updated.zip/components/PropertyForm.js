function PropertyForm({ regionName, onSuccess }) {
  try {
    const [data, setData] = React.useState({
      title: '', type: 'residential', price: '', area: '', 
      description: '', status: 'available', images: [], videos: [],
      bedrooms: '', bathrooms: '', floors: '', parking: '', furnished: ''
    });
    const [uploading, setUploading] = React.useState(false);
    const imageInputRef = React.useRef(null);
    const videoInputRef = React.useRef(null);

    const handleImageUpload = (e) => {
      const files = Array.from(e.target.files);
      if (files.length === 0) return;
      
      setUploading(true);
      const readers = files.map(file => {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = (event) => resolve(event.target.result);
          reader.readAsDataURL(file);
        });
      });
      
      Promise.all(readers).then(results => {
        setData({...data, images: [...data.images, ...results]});
        setUploading(false);
      });
    };

    const handleVideoUpload = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      setUploading(true);
      const reader = new FileReader();
      reader.onload = (event) => {
        setData({...data, videos: [...data.videos, event.target.result]});
        setUploading(false);
      };
      reader.readAsDataURL(file);
    };

    const handleSubmit = async (e) => {
      e.preventDefault();
      try {
        await Database.createProperty({ ...data, region: regionName });
        alert('تم إضافة العقار بنجاح');
        onSuccess();
      } catch (error) {
        alert('حدث خطأ');
      }
    };

    return (
      <form onSubmit={handleSubmit} className="bg-white p-4 rounded-lg space-y-3 border">
        <input type="text" required placeholder="عنوان العقار" 
          value={data.title} onChange={e => setData({...data, title: e.target.value})}
          className="w-full px-3 py-2 border rounded text-sm" />
        
        <div className="grid grid-cols-2 gap-2">
          <select value={data.type} onChange={e => setData({...data, type: e.target.value})}
            className="w-full px-3 py-2 border rounded text-sm">
            <option value="residential">سكني</option>
            <option value="commercial">تجاري</option>
          </select>
          
          <select value={data.status} onChange={e => setData({...data, status: e.target.value})}
            className="w-full px-3 py-2 border rounded text-sm">
            <option value="available">متاح</option>
            <option value="sold">تم البيع</option>
          </select>
        </div>
        
        <div className="grid grid-cols-2 gap-2">
          <input type="text" required placeholder="السعر" 
            value={data.price} onChange={e => setData({...data, price: e.target.value})}
            className="w-full px-3 py-2 border rounded text-sm" />
          
          <input type="text" required placeholder="المساحة (م²)" 
            value={data.area} onChange={e => setData({...data, area: e.target.value})}
            className="w-full px-3 py-2 border rounded text-sm" />
        </div>

        <div className="border-t pt-3">
          <p className="font-semibold text-sm mb-2">المميزات والتفاصيل:</p>
          <div className="grid grid-cols-2 gap-2">
            <input type="text" placeholder="عدد الغرف" 
              value={data.bedrooms} onChange={e => setData({...data, bedrooms: e.target.value})}
              className="w-full px-3 py-2 border rounded text-sm" />
            
            <input type="text" placeholder="عدد الحمامات" 
              value={data.bathrooms} onChange={e => setData({...data, bathrooms: e.target.value})}
              className="w-full px-3 py-2 border rounded text-sm" />
            
            <input type="text" placeholder="عدد الطوابق" 
              value={data.floors} onChange={e => setData({...data, floors: e.target.value})}
              className="w-full px-3 py-2 border rounded text-sm" />
            
            <input type="text" placeholder="مواقف سيارات" 
              value={data.parking} onChange={e => setData({...data, parking: e.target.value})}
              className="w-full px-3 py-2 border rounded text-sm" />
            
            <select value={data.furnished} onChange={e => setData({...data, furnished: e.target.value})}
              className="w-full px-3 py-2 border rounded text-sm">
              <option value="">حالة التأثيث</option>
              <option value="مفروش">مفروش</option>
              <option value="نصف مفروش">نصف مفروش</option>
              <option value="غير مفروش">غير مفروش</option>
            </select>

            <select value={data.view} onChange={e => setData({...data, view: e.target.value})}
              className="w-full px-3 py-2 border rounded text-sm">
              <option value="">الإطلالة</option>
              <option value="شارع رئيسي">شارع رئيسي</option>
              <option value="حديقة">حديقة</option>
              <option value="بحيرة">بحيرة</option>
              <option value="جبل">جبل</option>
            </select>
          </div>
        </div>
        
        <textarea placeholder="الوصف" rows="2"
          value={data.description} onChange={e => setData({...data, description: e.target.value})}
          className="w-full px-3 py-2 border rounded text-sm"></textarea>

        <div className="border-t pt-3 space-y-2">
          <div>
            <input type="file" ref={imageInputRef} onChange={handleImageUpload} accept="image/*" multiple className="hidden" />
            <button type="button" onClick={() => imageInputRef.current?.click()} 
              disabled={uploading}
              className="w-full px-3 py-2 bg-blue-500 text-white rounded text-sm hover:bg-blue-600 flex items-center justify-center gap-2">
              <div className="icon-image text-sm"></div>
              {uploading ? 'جاري الرفع...' : `رفع صور (${data.images.length})`}
            </button>
          </div>
          
          <div>
            <input type="file" ref={videoInputRef} onChange={handleVideoUpload} accept="video/*" className="hidden" />
            <button type="button" onClick={() => videoInputRef.current?.click()}
              disabled={uploading}
              className="w-full px-3 py-2 bg-purple-500 text-white rounded text-sm hover:bg-purple-600 flex items-center justify-center gap-2">
              <div className="icon-video text-sm"></div>
              {uploading ? 'جاري الرفع...' : `رفع فيديو (${data.videos.length})`}
            </button>
          </div>
        </div>
        
        <button type="submit" className="btn-primary w-full text-sm">حفظ العقار</button>
      </form>
    );
  } catch (error) {
    console.error('PropertyForm error:', error);
    return null;
  }
}
