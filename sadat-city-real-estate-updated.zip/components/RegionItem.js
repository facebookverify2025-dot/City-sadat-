function RegionItem({ region, onUpdate }) {
  try {
    const [showForm, setShowForm] = React.useState(false);
    const [showMapUpload, setShowMapUpload] = React.useState(false);
    const [properties, setProperties] = React.useState([]);
    const [mapUrl, setMapUrl] = React.useState(region.objectData.mapImage || '');
    const [uploading, setUploading] = React.useState(false);
    const mapFileInputRef = React.useRef(null);

    React.useEffect(() => {
      loadProperties();
    }, []);

    const loadProperties = async () => {
      const allProps = await Database.getProperties();
      setProperties(allProps.filter(p => p.objectData.region === region.objectData.name));
    };

    const handleDeleteProperty = async (propertyId) => {
      if (!confirm('هل أنت متأكد من حذف هذا العقار؟')) return;
      try {
        await Database.deleteProperty(propertyId);
        loadProperties();
        onUpdate();
        alert('تم حذف العقار بنجاح');
      } catch (error) {
        alert('حدث خطأ في حذف العقار');
      }
    };

    const handleMapFileUpload = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      console.log('File selected:', {
        name: file.name,
        type: file.type,
        size: file.size
      });
      
      const fileName = file.name.toLowerCase();
      const fileType = file.type;
      
      // Check file size (limit to 10MB)
      const maxSize = 10 * 1024 * 1024; // 10MB
      if (file.size > maxSize) {
        alert('حجم الملف كبير جداً. الحد الأقصى 10 ميجابايت');
        return;
      }
      
      const validImageTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
      const isPDF = fileType === 'application/pdf' || fileName.endsWith('.pdf');
      const isDWG = fileName.endsWith('.dwg') || fileType === 'application/octet-stream' || fileType === 'application/acad' || fileType === 'image/vnd.dwg';
      const isImage = validImageTypes.includes(fileType);
      
      if (!isImage && !isPDF && !isDWG) {
        alert('الرجاء اختيار صورة (JPG, PNG, GIF, WebP) أو ملف PDF أو DWG فقط');
        return;
      }
      
      setUploading(true);
      const reader = new FileReader();
      
      reader.onload = async (event) => {
        try {
          console.log('File read successfully, processing...');
          const result = event.target.result;
          let finalUrl = result;
          
          if (isPDF || isDWG) {
            finalUrl = result + '|' + file.name;
          }
          
          console.log('Updating region with map data...');
          setMapUrl(finalUrl);
          
          // Show immediate feedback
          setTimeout(async () => {
            try {
              await Database.updateRegion(region.objectId, {
                name: region.objectData.name,
                mapImage: finalUrl
              });
              
              console.log('Map saved successfully');
              alert('تم حفظ الخريطة بنجاح');
              setShowMapUpload(false);
              setUploading(false);
              onUpdate();
            } catch (updateError) {
              console.error('Database update error:', updateError);
              alert(`حدث خطأ في حفظ الخريطة: ${updateError.message}`);
              setUploading(false);
            }
          }, 100);
          
        } catch (error) {
          console.error('File processing error:', error);
          alert('حدث خطأ في معالجة الملف');
          setUploading(false);
        }
      };
      
      reader.onerror = (error) => {
        console.error('File reading error:', error);
        alert('حدث خطأ في قراءة الملف');
        setUploading(false);
      };
      
      reader.readAsDataURL(file);
    };

    const handleMapUrlSave = async () => {
      if (!mapUrl || mapUrl.trim() === '') {
        alert('الرجاء إدخال رابط الخريطة أولاً');
        return;
      }
      
      // Validate URL format
      try {
        new URL(mapUrl);
      } catch (error) {
        alert('الرجاء إدخال رابط صحيح');
        return;
      }
      
      console.log('Saving map URL:', mapUrl);
      
      try {
        await Database.updateRegion(region.objectId, {
          name: region.objectData.name,
          mapImage: mapUrl
        });
        
        console.log('Map URL saved successfully');
        alert('تم حفظ رابط الخريطة بنجاح');
        setShowMapUpload(false);
        onUpdate();
      } catch (error) {
        console.error('Map URL save error:', error);
        alert(`حدث خطأ في حفظ رابط الخريطة: ${error.message}`);
      }
    };

    const handleDeleteRegion = async () => {
      if (!confirm('هل أنت متأكد من حذف هذه المنطقة؟ سيتم حذف جميع العقارات المرتبطة بها')) return;
      try {
        const regionProps = await Database.getProperties();
        const propsToDelete = regionProps.filter(p => p.objectData.region === region.objectData.name);
        
        for (const prop of propsToDelete) {
          await Database.deleteProperty(prop.objectId);
        }
        
        await Database.deleteRegion(region.objectId);
        alert('تم حذف المنطقة بنجاح');
        onUpdate();
      } catch (error) {
        alert('حدث خطأ في حذف المنطقة');
      }
    };

    return (
      <div className="border rounded-lg p-4 bg-gray-50">
        <div className="flex justify-between items-center mb-4">
          <h4 className="text-lg font-bold">{region.objectData.name}</h4>
          <div className="flex gap-2">
            <button onClick={() => setShowMapUpload(!showMapUpload)} className="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600">
              {showMapUpload ? 'إلغاء' : 'إضافة خريطة'}
            </button>
            <button onClick={() => setShowForm(!showForm)} className="px-3 py-1 bg-[var(--primary-color)] text-white rounded text-sm hover:bg-[var(--secondary-color)]">
              {showForm ? 'إلغاء' : 'إضافة عقار'}
            </button>
            <button onClick={handleDeleteRegion} className="px-3 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-600 flex items-center gap-1">
              <div className="icon-trash-2 text-sm"></div>
              حذف المنطقة
            </button>
          </div>
        </div>

        {showMapUpload && (
          <div className="bg-white p-4 rounded-lg mb-4 border">
            <div className="mb-3">
              <label className="block font-semibold mb-2 text-sm">رفع صورة من الجهاز</label>
              <input 
                type="file"
                ref={mapFileInputRef}
                onChange={handleMapFileUpload}
                accept="image/*,application/pdf,.dwg"
                className="hidden"
              />
              <button 
                type="button"
                onClick={() => mapFileInputRef.current?.click()}
                disabled={uploading}
                className="w-full px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all flex items-center justify-center gap-2 text-sm"
              >
                <div className="icon-upload text-lg"></div>
                {uploading ? 'جاري الرفع...' : 'اختر صورة أو PDF أو DWG'}
              </button>
            </div>

            <div className="relative mb-3">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="bg-white px-2 text-gray-500">أو</span>
              </div>
            </div>

            <div className="mb-3">
              <label className="block font-semibold mb-2 text-sm">رابط صورة الخريطة</label>
              <div className="flex gap-2">
                <input 
                  type="url"
                  value={mapUrl}
                  onChange={e => setMapUrl(e.target.value)}
                  placeholder="https://example.com/map.jpg"
                  className="flex-1 px-3 py-2 border rounded-lg text-sm"
                />
                <button onClick={handleMapUrlSave} className="px-4 py-2 bg-[var(--primary-color)] text-white rounded-lg hover:bg-[var(--secondary-color)] text-sm whitespace-nowrap">
                  حفظ
                </button>
              </div>
              <p className="text-xs text-gray-500 mt-1">أو استخدم رابط مباشر للصورة</p>
            </div>

            {mapUrl && (
              <div className="mb-3">
                <p className="text-sm text-gray-600 mb-2">معاينة الخريطة:</p>
                {(() => {
                  const urlParts = mapUrl.split('|');
                  const dataUrl = urlParts[0];
                  const fileName = urlParts[1] || '';
                  
                  if (dataUrl.includes('application/pdf') || fileName.endsWith('.pdf')) {
                    return (
                      <div className="w-full max-w-xs p-4 border rounded bg-red-50 flex items-center gap-3">
                        <div className="icon-file-text text-3xl text-red-600"></div>
                        <div>
                          <p className="font-semibold text-gray-800">ملف PDF</p>
                          <p className="text-xs text-gray-500">{fileName || 'تم رفع ملف PDF بنجاح'}</p>
                          <p className="text-xs text-green-600 font-medium">✓ تم الرفع بنجاح</p>
                        </div>
                      </div>
                    );
                  } else if (fileName.endsWith('.dwg') || dataUrl.includes('octet-stream')) {
                    return (
                      <div className="w-full max-w-xs p-4 border rounded bg-blue-50 flex items-center gap-3">
                        <div className="icon-file text-3xl text-blue-600"></div>
                        <div>
                          <p className="font-semibold text-gray-800">ملف DWG</p>
                          <p className="text-xs text-gray-500">{fileName || 'تم رفع ملف DWG بنجاح'}</p>
                          <p className="text-xs text-green-600 font-medium">✓ تم الرفع بنجاح</p>
                        </div>
                      </div>
                    );
                  } else if (dataUrl.startsWith('data:image/')) {
                    return (
                      <div className="w-full max-w-xs">
                        <img src={dataUrl} alt="Map Preview" className="w-full rounded border" />
                        <p className="text-xs text-green-600 font-medium mt-1 text-center">✓ تم رفع الصورة بنجاح</p>
                      </div>
                    );
                  } else {
                    return (
                      <div className="w-full max-w-xs p-4 border rounded bg-gray-50 flex items-center gap-3">
                        <div className="icon-image text-3xl text-gray-600"></div>
                        <div>
                          <p className="font-semibold text-gray-800">ملف خريطة</p>
                          <p className="text-xs text-gray-500">{fileName || 'تم رفع الملف بنجاح'}</p>
                          <p className="text-xs text-green-600 font-medium">✓ تم الرفع بنجاح</p>
                        </div>
                      </div>
                    );
                  }
                })()}
              </div>
            )}
          </div>
        )}

        {showForm && <PropertyForm regionName={region.objectData.name} onSuccess={() => { setShowForm(false); loadProperties(); onUpdate(); }} />}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {properties.map(prop => (
            <div key={prop.objectId} className="border rounded p-3 bg-white">
              <div className="flex justify-between items-start mb-2">
                <div className="flex-1">
                  <p className="font-semibold">{prop.objectData.title}</p>
                  <p className="text-sm text-gray-600">{prop.objectData.price} جنيه</p>
                  <p className="text-xs text-gray-500">{prop.objectData.type === 'residential' ? 'سكني' : 'تجاري'}</p>
                </div>
                <button 
                  onClick={() => handleDeleteProperty(prop.objectId)}
                  className="px-2 py-1 bg-red-500 text-white rounded text-xs hover:bg-red-600"
                >
                  حذف
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  } catch (error) {
    console.error('RegionItem error:', error);
    return null;
  }
}
