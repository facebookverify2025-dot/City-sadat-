function Footer({ settings, onNavigate }) {
  try {
    const data = settings.objectData || {};
    const whatsappNumber = data.whatsappNumber || '+201034551612';
    const facebookUrl = data.facebookUrl || '#';
    const instagramUrl = data.instagramUrl || '#';

    return (
      <footer className="bg-[var(--dark-color)] text-white py-6 sm:py-8 md:py-12" data-name="footer" data-file="components/Footer.js">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6 md:gap-8 mb-4 sm:mb-6 md:mb-8">
            <div>
              <h3 className="text-xl sm:text-2xl font-bold mb-3 sm:mb-4">الجنرال</h3>
              <p className="text-sm sm:text-base text-gray-400">مسوق عقارات حقيقي في مدينة السادات</p>
            </div>
            
            <div>
              <h4 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">تواصل معنا</h4>
              <div className="space-y-2 text-gray-400">
                <div className="flex items-center gap-2">
                  <div className="icon-phone text-[var(--primary-color)]"></div>
                  <span>+201274343881</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="icon-smartphone text-[var(--primary-color)]"></div>
                  <span>+201012743438</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="icon-message-circle text-[var(--primary-color)]"></div>
                  <span>واتساب: {whatsappNumber}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="icon-map-pin text-[var(--primary-color)]"></div>
                  <span>السادات، مصر</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">تابعنا</h4>
              <div className="flex gap-3 sm:gap-4">
                <a href={facebookUrl} target="_blank" rel="noopener noreferrer" 
                   className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition-all">
                  <div className="icon-facebook text-lg sm:text-xl text-white"></div>
                </a>
                <a href={instagramUrl} target="_blank" rel="noopener noreferrer"
                   className="w-10 h-10 sm:w-12 sm:h-12 bg-pink-600 rounded-full flex items-center justify-center hover:bg-pink-700 transition-all">
                  <div className="icon-instagram text-lg sm:text-xl text-white"></div>
                </a>
                <a href={`https://wa.me/${whatsappNumber.replace(/\+/g, '')}`} target="_blank" rel="noopener noreferrer"
                   className="w-10 h-10 sm:w-12 sm:h-12 bg-green-600 rounded-full flex items-center justify-center hover:bg-green-700 transition-all">
                  <div className="icon-message-circle text-lg sm:text-xl text-white"></div>
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-700 pt-4 sm:pt-6 text-center text-gray-400">
            <p className="text-sm sm:text-base">© 2025 الجنرال. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    );
  } catch (error) {
    console.error('Footer component error:', error);
    return null;
  }
}