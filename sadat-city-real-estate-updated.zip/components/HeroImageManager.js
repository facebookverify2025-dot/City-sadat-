function HeroImageManager({ onUpdate }) {
  try {
    const [settings, setSettings] = React.useState(null);
    const [heroImageUrl, setHeroImageUrl] = React.useState('');
    const [uploading, setUploading] = React.useState(false);
    const fileInputRef = React.useRef(null);

    React.useEffect(() => {
      loadSettings();
    }, []);

    const handleFileUpload = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      if (!file.type.startsWith('image/')) {
        alert('الرجاء اختيار صورة فقط');
        return;
      }
      
      setUploading(true);
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64Image = event.target.result;
        setHeroImageUrl(base64Image);
        setUploading(false);
      };
      reader.onerror = () => {
        alert('حدث خطأ في قراءة الملف');
        setUploading(false);
      };
      reader.readAsDataURL(file);
    };

    const loadSettings = async () => {
      const s = await Database.getSettings();
      setSettings(s);
      setHeroImageUrl(s.objectData?.heroImageUrl || 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80');
    };

    const handleSave = async () => {
      if (!heroImageUrl || heroImageUrl.trim() === '') {
        alert('الرجاء إضافة صورة أولاً');
        return;
      }
      
      if (!settings || !settings.objectId) {
        alert('خطأ في تحميل الإعدادات. الرجاء إعادة تحميل الصفحة');
        return;
      }
      
      try {
        const currentData = settings.objectData || {};
        const updatedData = {
          companyEmail: currentData.companyEmail || 'info@general.com',
          whatsappNumber: currentData.whatsappNumber || '+201034551612',
          facebookUrl: currentData.facebookUrl || '',
          instagramUrl: currentData.instagramUrl || '',
          heroImageUrl: heroImageUrl
        };
        
        await Database.updateSettings(settings.objectId, updatedData);
        alert('تم حفظ صورة الخلفية بنجاح');
        await loadSettings();
        onUpdate();
      } catch (error) {
        console.error('Save hero image error:', error);
        alert('حدث خطأ في حفظ الصورة: ' + error.message);
      }
    };

    if (!settings) return <div>جاري التحميل...</div>;

    return (
      <div className="space-y-4" data-name="hero-image-manager" data-file="components/HeroImageManager.js">
        <h3 className="text-xl font-bold mb-4">إدارة صورة الخلفية الرئيسية</h3>
        
        <div>
          <label className="block font-semibold mb-2">رفع صورة من جهازك</label>
          <input 
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*"
            className="hidden"
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="w-full px-4 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all mb-4 flex items-center justify-center gap-2"
          >
            <div className="icon-upload text-xl"></div>
            {uploading ? 'جاري الرفع...' : 'اختر صورة من جهازك'}
          </button>
        </div>

        <div className="relative">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <span className="text-gray-500">أو</span>
          </div>
        </div>

        <div>
          <label className="block font-semibold mb-2">رابط صورة الخلفية</label>
          <input 
            type="url" 
            value={heroImageUrl} 
            onChange={e => setHeroImageUrl(e.target.value)}
            placeholder="https://example.com/hero-image.jpg"
            className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
          />
          <p className="text-xs text-gray-500 mt-2">
            أو استخدم رابط مباشر للصورة. يُفضل استخدام صور عالية الجودة بأبعاد 1920x1080 أو أكبر
          </p>
        </div>

        {heroImageUrl && (
          <div>
            <label className="block font-semibold mb-2">معاينة الصورة الحالية:</label>
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img 
                src={heroImageUrl} 
                alt="Hero Background" 
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.nextSibling.style.display = 'flex';
                }}
              />
              <div className="hidden absolute inset-0 bg-gray-200 items-center justify-center">
                <p className="text-gray-500">فشل تحميل الصورة - تأكد من صحة الرابط</p>
              </div>
            </div>
          </div>
        )}
        
        <button onClick={handleSave} className="btn-primary">
          حفظ صورة الخلفية
        </button>
      </div>
    );
  } catch (error) {
    console.error('HeroImageManager error:', error);
    return null;
  }
}