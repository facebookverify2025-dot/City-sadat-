function MessagesManager() {
  try {
    const [messages, setMessages] = React.useState([]);

    React.useEffect(() => {
      loadMessages();
      const interval = setInterval(loadMessages, 5000);
      return () => clearInterval(interval);
    }, []);

    const loadMessages = async () => {
      const data = await Database.getMessages();
      setMessages(data);
    };

    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold mb-4">الرسائل الواردة</h3>
        {messages.length === 0 ? (
          <p className="text-gray-500">لا توجد رسائل</p>
        ) : (
          messages.map(msg => (
            <div key={msg.objectId} className="border rounded-lg p-4 bg-gray-50">
              <div className="flex justify-between mb-2">
                <strong>{msg.objectData.name}</strong>
                <span className="text-sm text-gray-500">
                  {new Date(msg.createdAt).toLocaleDateString('ar-EG')}
                </span>
              </div>
              <p className="text-sm text-gray-600 mb-1">{msg.objectData.email}</p>
              <p className="text-sm text-gray-600 mb-2">{msg.objectData.phone}</p>
              <p className="mt-2">{msg.objectData.message}</p>
            </div>
          ))
        )}
      </div>
    );
  } catch (error) {
    console.error('MessagesManager error:', error);
    return null;
  }
}