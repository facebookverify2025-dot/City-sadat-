function Header({ currentPage, onNavigate, isAdmin }) {
  try {
    const [isMenuOpen, setIsMenuOpen] = React.useState(false);
    const [realtimeStatus, setRealtimeStatus] = React.useState({ connected: false, reconnectAttempts: 0 });

    // Update real-time status
    React.useEffect(() => {
      if (window.trickleGetRealTimeStatus) {
        const updateStatus = () => {
          setRealtimeStatus(window.trickleGetRealTimeStatus());
        };
        
        // Initial status
        updateStatus();
        
        // Listen for real-time updates
        if (window.trickleOnUpdate) {
          window.trickleOnUpdate('connection', updateStatus);
        }
        
        // Update status every 5 seconds
        const interval = setInterval(updateStatus, 5000);
        
        return () => {
          if (window.trickleOffUpdate) {
            window.trickleOffUpdate('connection', updateStatus);
          }
          clearInterval(interval);
        };
      }
    }, []);

    const menuItems = [
      { id: 'home', label: 'الرئيسية', icon: 'home' },
      { id: 'about', label: 'من نحن', icon: 'users' },
      { id: 'projects', label: 'المشاريع', icon: 'building-2' },
      { id: 'maps', label: 'الخرائط', icon: 'map' },
      { id: 'contact', label: 'تواصل معنا', icon: 'phone' }
    ];

    return (
      <header className="bg-white shadow-md sticky top-0 z-50" data-name="header" data-file="components/Header.js">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-2 md:gap-3">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-[var(--primary-color)] rounded-lg flex items-center justify-center">
              <div className="icon-building-2 text-xl md:text-2xl text-white"></div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg md:text-2xl font-bold text-[var(--dark-color)]">الجنرال</h1>
                <div className="flex items-center gap-1">
                  <div className={`w-2 h-2 rounded-full ${
                    realtimeStatus.connected ? 'bg-green-500 animate-pulse' : 'bg-red-500'
                  }`}></div>
                  <span className="text-xs text-gray-500 hidden sm:block">
                    {realtimeStatus.connected ? 'مباشر' : 'عدم اتصال'}
                  </span>
                </div>
              </div>
              <p className="text-xs hidden sm:block text-gray-600">مسوق عقارات حقيقي في مدينة السادات</p>
            </div>
          </div>

            <nav className="hidden lg:flex items-center gap-4 xl:gap-6">
              {menuItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                    currentPage === item.id ? 'bg-[var(--primary-color)] text-white' : 'hover:bg-gray-100'
                  }`}
                >
                  <div className={`icon-${item.icon} text-lg`}></div>
                  <span className="font-semibold">{item.label}</span>
                </button>
              ))}
            </nav>

            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="lg:hidden p-2">
              <div className={`icon-${isMenuOpen ? 'x' : 'menu'} text-2xl text-[var(--dark-color)]`}></div>
            </button>
          </div>

          {isMenuOpen && (
            <nav className="lg:hidden py-4 border-t">
              {menuItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => { onNavigate(item.id); setIsMenuOpen(false); }}
                  className={`w-full text-right px-4 py-3 rounded-lg flex items-center gap-3 ${
                    currentPage === item.id ? 'bg-[var(--primary-color)] text-white' : 'hover:bg-gray-100'
                  }`}
                >
                  <div className={`icon-${item.icon} text-lg`}></div>
                  <span className="font-semibold">{item.label}</span>
                </button>
              ))}
            </nav>
          )}
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}