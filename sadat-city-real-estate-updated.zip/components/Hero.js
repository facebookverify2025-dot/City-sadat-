function Hero({ onNavigate, heroImageUrl }) {
  try {
    const defaultImage = 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80';
    const bgImage = heroImageUrl || defaultImage;
    
    return (
      <section 
        className="relative h-[500px] sm:h-[550px] md:h-[600px] flex items-center justify-center bg-cover bg-center"
        style={{ backgroundImage: `url(${bgImage})` }}
        data-name="hero" 
        data-file="components/Hero.js"
      >
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        
        <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
          <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold mb-4 md:mb-6 text-shadow leading-tight">
            مرحباً بك في الجنرال
          </h1>
          <p className="text-sm sm:text-base md:text-lg lg:text-xl xl:text-2xl mb-6 md:mb-8 text-shadow">
            مشاريع عقارية متميزة في قلب مدينة السادات
          </p>
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center px-4">
            <button onClick={() => onNavigate('projects')} className="btn-primary text-base sm:text-lg w-full sm:w-auto">
              استعرض المشاريع
            </button>
            <button onClick={() => onNavigate('contact')} className="px-6 py-3 bg-white text-[var(--dark-color)] rounded-lg font-semibold hover:bg-gray-100 transition-all duration-300 shadow-md text-base sm:text-lg w-full sm:w-auto">
              تواصل معنا
            </button>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Hero component error:', error);
    return null;
  }
}