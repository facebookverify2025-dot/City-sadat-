function RegionsManager({ onUpdate }) {
  try {
    const [regions, setRegions] = React.useState([]);
    const [newRegion, setNewRegion] = React.useState('');
    const [showPropertyForm, setShowPropertyForm] = React.useState(null);

    React.useEffect(() => {
      loadRegions();
    }, []);

    const loadRegions = async () => {
      const data = await Database.getRegions();
      setRegions(data);
    };

    const handleAddRegion = async () => {
      if (!newRegion.trim()) return;
      try {
        await Database.createRegion(newRegion);
        setNewRegion('');
        loadRegions();
        onUpdate();
      } catch (error) {
        alert('حدث خطأ');
      }
    };

    return (
      <div data-name="regions-manager" data-file="components/RegionsManager.js">
        <div className="mb-6">
          <h3 className="text-xl font-bold mb-4">إضافة منطقة جديدة</h3>
          <div className="flex gap-2">
            <input 
              type="text"
              value={newRegion}
              onChange={e => setNewRegion(e.target.value)}
              placeholder="اسم المنطقة"
              className="flex-1 px-4 py-2 border rounded-lg"
            />
            <button onClick={handleAddRegion} className="btn-primary">
              إضافة
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {regions.map(region => (
            <RegionItem 
              key={region.objectId} 
              region={region} 
              onUpdate={() => { loadRegions(); onUpdate(); }}
            />
          ))}
        </div>
      </div>
    );
  } catch (error) {
    console.error('RegionsManager error:', error);
    return null;
  }
}