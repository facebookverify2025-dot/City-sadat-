function ContactPage({ settings }) {
  try {
    const [formData, setFormData] = React.useState({ name: '', email: '', phone: '', message: '' });
    const [sending, setSending] = React.useState(false);

    const handleSubmit = async (e) => {
      e.preventDefault();
      setSending(true);
      try {
        await Database.createMessage(formData);
        alert('تم إرسال رسالتك بنجاح! سنتواصل معك قريباً');
        setFormData({ name: '', email: '', phone: '', message: '' });
      } catch (error) {
        alert('حدث خطأ في إرسال الرسالة');
      }
      setSending(false);
    };

    return (
      <div className="py-8 md:py-16 bg-[var(--light-bg)]" data-name="contact-page" data-file="pages/contact.js">
        <div className="container mx-auto px-4 max-w-2xl">
          <h1 className="section-title text-2xl md:text-4xl">تواصل معنا</h1>
          
          <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-lg p-4 md:p-8">
            <div className="mb-4">
              <label className="block text-gray-700 font-semibold mb-2">الاسم</label>
              <input 
                type="text" 
                required
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
                className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              />
            </div>
            
            <div className="mb-4">
              <label className="block text-gray-700 font-semibold mb-2">البريد الإلكتروني</label>
              <input 
                type="email" 
                required
                value={formData.email}
                onChange={e => setFormData({...formData, email: e.target.value})}
                className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              />
            </div>
            
            <div className="mb-4">
              <label className="block text-gray-700 font-semibold mb-2">رقم الهاتف</label>
              <input 
                type="tel" 
                required
                value={formData.phone}
                onChange={e => setFormData({...formData, phone: e.target.value})}
                className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              />
            </div>
            
            <div className="mb-6">
              <label className="block text-gray-700 font-semibold mb-2">الرسالة</label>
              <textarea 
                required
                rows="5"
                value={formData.message}
                onChange={e => setFormData({...formData, message: e.target.value})}
                className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:border-[var(--primary-color)]"
              ></textarea>
            </div>
            
            <button type="submit" disabled={sending} className="w-full btn-primary">
              {sending ? 'جاري الإرسال...' : 'إرسال'}
            </button>
          </form>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ContactPage error:', error);
    return null;
  }
}