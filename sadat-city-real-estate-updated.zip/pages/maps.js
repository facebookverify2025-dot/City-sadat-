function MapsPage({ regions }) {
  try {
    const [selectedRegion, setSelectedRegion] = React.useState(null);
    const [regionsData, setRegionsData] = React.useState(regions || []);
    const mapRef = React.useRef(null);
    const googleMapRef = React.useRef(null);

    // Load regions data
    const loadRegionsData = React.useCallback(async () => {
      try {
        const result = await window.trickleListObjects('regions');
        if (result.items) {
          setRegionsData(result.items);
        }
      } catch (error) {
        console.error('Error loading regions data:', error);
      }
    }, []);

    // Real-time data change handler
    const handleDataChange = React.useCallback((data) => {
      if (data.table === 'regions' || data.table === 'all') {
        console.log('📡 Real-time update received for regions:', data);
        loadRegionsData();
      }
    }, [loadRegionsData]);

    // Set up real-time listeners
    React.useEffect(() => {
      if (window.trickleOnUpdate) {
        window.trickleOnUpdate('dataChange', handleDataChange);
        return () => {
          if (window.trickleOffUpdate) {
            window.trickleOffUpdate('dataChange', handleDataChange);
          }
        };
      }
    }, [handleDataChange]);

    // Load initial data if not provided
    React.useEffect(() => {
      if (!regions || regions.length === 0) {
        loadRegionsData();
      } else {
        setRegionsData(regions);
      }
    }, [regions, loadRegionsData]);

    React.useEffect(() => {
      if (mapRef.current && !googleMapRef.current && window.google) {
        const sadatCity = { lat: 30.3753, lng: 30.5669 };
        
        googleMapRef.current = new google.maps.Map(mapRef.current, {
          center: sadatCity,
          zoom: 13,
          mapTypeId: 'roadmap',
          language: 'ar'
        });

        new google.maps.Marker({
          position: sadatCity,
          map: googleMapRef.current,
          title: 'مدينة السادات'
        });
      }
    }, []);

    return (
      <div className="py-16 bg-white" data-name="maps-page" data-file="pages/maps.js">
        <div className="container mx-auto px-4">
          <h1 className="section-title">الخرائط</h1>
          
          <div className="mb-12">
            <div className="card overflow-hidden">
              <div className="bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] p-6 text-white">
                <h2 className="text-3xl font-bold mb-2">خريطة مدينة السادات</h2>
                <p className="text-lg">خريطة تفاعلية من Google Maps</p>
              </div>
              <div ref={mapRef} className="w-full h-[500px]"></div>
            </div>
          </div>

          <h2 className="text-2xl font-bold mb-6">خرائط المناطق</h2>
          <div className="mb-4 flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${window.trickleGetRealTimeStatus ? (window.trickleGetRealTimeStatus().connected ? 'bg-green-500' : 'bg-red-500') : 'bg-gray-500'}`}></div>
            <span className="text-sm text-gray-600">
              {window.trickleGetRealTimeStatus ? (window.trickleGetRealTimeStatus().connected ? 'متصل - تحديث فوري' : 'غير متصل') : 'جاري التحميل...'}
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {regionsData.map(region => {
              const mapData = region.objectData.mapImage;
              const urlParts = mapData ? mapData.split('|') : [];
              const dataUrl = urlParts[0];
              const fileName = urlParts[1] || '';
              
              // Determine file type
              const isPDF = fileName.toLowerCase().endsWith('.pdf') || (dataUrl && dataUrl.includes('application/pdf'));
              const isImage = dataUrl && dataUrl.startsWith('data:image/') && !isPDF;
              const hasFile = region.objectData.mapImage;
              
              return (
                <div 
                  key={region.objectId}
                  onClick={() => {
                    if (hasFile) {
                      // Create blob and object URL for better compatibility
                      try {
                        // Convert data URL to binary data
                        const byteCharacters = atob(dataUrl.split(',')[1]);
                        const byteNumbers = new Array(byteCharacters.length);
                        for (let i = 0; i < byteCharacters.length; i++) {
                          byteNumbers[i] = byteCharacters.charCodeAt(i);
                        }
                        const byteArray = new Uint8Array(byteNumbers);
                        
                        // Determine MIME type
                        let mimeType = 'application/octet-stream';
                        if (dataUrl.includes('application/pdf')) mimeType = 'application/pdf';
                        else if (dataUrl.includes('image/jpeg')) mimeType = 'image/jpeg';
                        else if (dataUrl.includes('image/png')) mimeType = 'image/png';
                        else if (dataUrl.includes('image/jpg')) mimeType = 'image/jpg';
                        else if (dataUrl.includes('image/gif')) mimeType = 'image/gif';
                        
                        // Create blob
                        const blob = new Blob([byteArray], { type: mimeType });
                        const objectUrl = URL.createObjectURL(blob);
                        
                        // Open in new window
                        const newWindow = window.open(objectUrl, '_blank');
                        if (!newWindow) {
                          alert('من فضلك اسمح بالنوافذ المنبثقة لفتح الملف');
                        }
                        
                        // Clean up object URL after 30 seconds
                        setTimeout(() => URL.revokeObjectURL(objectUrl), 30000);
                        
                      } catch (error) {
                        console.error('Error opening file:', error);
                        // Fallback: try direct data URL
                        try {
                          const newWindow = window.open(dataUrl, '_blank');
                          if (!newWindow) {
                            alert('فشل في فتح الملف. من فضلك تحقق من إعدادات المتصفح');
                          }
                        } catch (fallbackError) {
                          console.error('Fallback failed:', fallbackError);
                          alert('فشل في فتح الملف');
                        }
                      }
                    } else {
                      // Show modal for regions without files
                      setSelectedRegion(region);
                    }
                  }}
                  className="card cursor-pointer hover:shadow-lg transition-shadow"
                >
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <div className="icon-map text-xl text-blue-600"></div>
                      </div>
                      <h3 className="text-xl font-bold">{region.objectData.name}</h3>
                    </div>
                    {hasFile ? (
                      <div>
                        <p className="text-green-600 text-sm mb-2">✓ توجد خريطة</p>
                        {isPDF && <p className="text-blue-600 text-xs">📄 ملف PDF - انقر لفتحه</p>}
                        {isImage && <p className="text-blue-600 text-xs">🖼️ صورة - انقر لفتحها</p>}
                        {!isPDF && !isImage && <p className="text-blue-600 text-xs">📁 ملف - انقر لفتحه</p>}
                        <p className="text-gray-500 text-xs mt-1">سيُفتح في نافذة جديدة</p>
                      </div>
                    ) : (
                      <p className="text-gray-500 text-sm">لم تُضف خريطة بعد</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {selectedRegion && (
            <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4" onClick={() => setSelectedRegion(null)}>
              <div className="bg-white rounded-xl max-w-4xl w-full p-6 max-h-[90vh] overflow-auto" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-2xl font-bold">{selectedRegion.objectData.name}</h2>
                  <button onClick={() => setSelectedRegion(null)} className="text-gray-500 hover:text-gray-700">
                    <div className="icon-x text-2xl"></div>
                  </button>
                </div>
                {selectedRegion.objectData.mapImage ? (
                  (() => {
                    const mapData = selectedRegion.objectData.mapImage;
                    const urlParts = mapData.split('|');
                    const dataUrl = urlParts[0];
                    const fileName = urlParts[1] || '';
                    
                    console.log('Selected region:', {
                      id: selectedRegion.objectId,
                      name: selectedRegion.objectData.name,
                      mapData: mapData.substring(0, 100) + '...',
                      dataUrlLength: dataUrl.length,
                      fileName: fileName
                    });
                    
                    // Add debug info to the UI
                    const debugInfo = {
                      regionName: selectedRegion.objectData.name,
                      hasMapData: !!mapData,
                      dataUrlLength: dataUrl.length,
                      fileName: fileName,
                      isDataURL: dataUrl.startsWith('data:')
                    };
                    console.log('Debug info:', debugInfo);
                    
                    // Determine file type based on filename or dataUrl
                    const isPDF = fileName.toLowerCase().endsWith('.pdf') || dataUrl.includes('application/pdf') || dataUrl.includes('data:application/pdf');
                    const isDWG = fileName.toLowerCase().endsWith('.dwg') || dataUrl.includes('application/octet-stream') || dataUrl.includes('data:application/octet-stream');
                    const isImage = dataUrl.startsWith('data:image/') && !isPDF && !isDWG;
                    
                    if (isPDF) {
                      return (
                        <div className="w-full h-[70vh] flex flex-col gap-4">
                          <div className="w-full h-[60vh] bg-gray-50 rounded-lg border flex items-center justify-center">
                            <div className="text-center">
                              <div className="icon-file-text text-6xl text-red-600 mb-4 mx-auto"></div>
                              <p className="text-xl font-semibold text-gray-800 mb-2">ملف PDF للخريطة</p>
                              <p className="text-gray-600 mb-2">تم رفع الملف بنجاح</p>
                              <p className="text-sm text-gray-500 mb-4">
                                {fileName || `${selectedRegion.objectData.name}-map.pdf`}
                              </p>
                              <p className="text-sm text-blue-600">
                                💡 لتحميل الملف واستخدامه في قارئ PDF
                              </p>
                            </div>
                          </div>
                          <div className="flex gap-3 justify-center">
                            <a 
                              href={dataUrl} 
                              download={fileName || `${selectedRegion.objectData.name}-map.pdf`}
                              className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all flex items-center gap-2"
                            >
                              <div className="icon-download text-xl"></div>
                              تنزيل الملف
                            </a>
                          </div>
                        </div>
                      );
                    } else if (isDWG) {
                      return (
                        <div className="w-full h-[70vh] flex flex-col gap-4">
                          <div className="w-full h-[60vh] flex items-center justify-center bg-gray-50 rounded-lg border">
                            <div className="text-center">
                              <div className="icon-file text-6xl text-blue-600 mb-4 mx-auto"></div>
                              <p className="text-xl font-semibold text-gray-800 mb-2">ملف DWG</p>
                              <p className="text-gray-600 mb-4">قم بتحميل الملف لفتحه في برنامج AutoCAD</p>
                              <p className="text-sm text-gray-500 mb-4">
                                {fileName || `${selectedRegion.objectData.name}-map.dwg`}
                              </p>
                            </div>
                          </div>
                          <div className="flex gap-3 justify-center">
                            <a 
                              href={dataUrl} 
                              download={fileName || `${selectedRegion.objectData.name}-map.dwg`}
                              className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all flex items-center gap-2"
                            >
                              <div className="icon-download text-xl"></div>
                              تنزيل الملف
                            </a>
                          </div>
                        </div>
                      );
                    } else if (isImage) {
                      // Check if data URL is not too large for safe viewing
                      const isImageSizeSafe = dataUrl.length < 1000000; // Less than 1MB
                      
                      return (
                        <div className="w-full h-[70vh] flex flex-col gap-4">
                          <div className="relative w-full h-[60vh] rounded-lg border overflow-hidden">
                            <img 
                              src={dataUrl} 
                              alt="Map" 
                              className="w-full h-full object-contain bg-gray-50"
                              onError={(e) => {
                                console.error('Error loading image:', e);
                                e.target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjNmNGY2Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzllYTNhOCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPuaYqdiq2KfZitipPC90ZXh0Pjwvc3ZnPg==';
                              }}
                              onLoad={() => console.log('Image loaded successfully')}
                            />
                            {dataUrl.startsWith('data:') && (
                              <div className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded text-xs">
                                صورة محلية
                              </div>
                            )}
                          </div>
                          <div className="flex gap-3 justify-center">
                            {isImageSizeSafe && (
                              <button 
                                onClick={() => {
                                  // Open in a new tab with proper error handling
                                  try {
                                    const newWindow = window.open('', '_blank');
                                    if (newWindow) {
                                      newWindow.document.write(`
                                        <html>
                                          <head>
                                            <title>عرض الخريطة - ${selectedRegion.objectData.name}</title>
                                            <style>
                                              body { margin: 0; padding: 20px; background: #f3f4f6; display: flex; flex-direction: column; align-items: center; }
                                              .container { max-width: 100%; max-height: 100vh; }
                                              img { max-width: 100%; max-height: 80vh; object-fit: contain; border: 1px solid #d1d5db; border-radius: 8px; }
                                              .info { margin-top: 10px; text-align: center; color: #374151; }
                                            </style>
                                          </head>
                                          <body>
                                            <div class="container">
                                              <h1 style="color: #1f2937; margin-bottom: 20px;">خريطة ${selectedRegion.objectData.name}</h1>
                                              <img src="${dataUrl}" alt="خريطة" />
                                              <div class="info">
                                                <p>${fileName || 'ملف خريطة'}</p>
                                              </div>
                                            </div>
                                          </body>
                                        </html>
                                      `);
                                      newWindow.document.close();
                                    } else {
                                      alert('من فضلك اسمح بالنوافذ المنبثقة لعرض الصورة');
                                    }
                                  } catch (error) {
                                    console.error('Error opening image:', error);
                                    alert('خطأ في فتح الصورة');
                                  }
                                }}
                                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all flex items-center gap-2"
                              >
                                <div className="icon-eye text-xl"></div>
                                عرض الملف
                              </button>
                            )}
                            <a 
                              href={dataUrl} 
                              download={`${selectedRegion.objectData.name}-map${fileName.includes('.') ? '.' + fileName.split('.').pop() : '.png'}`}
                              className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all flex items-center gap-2"
                            >
                              <div className="icon-download text-xl"></div>
                              تنزيل الملف
                            </a>
                          </div>
                          {!isImageSizeSafe && (
                            <p className="text-center text-yellow-600 text-sm">
                              ⚠️ الصورة كبيرة جداً لعرضها - استخدم زر التحميل بدلاً من ذلك
                            </p>
                          )}
                        </div>
                      );
                    } else {
                      return (
                        <div className="w-full h-[70vh] flex flex-col gap-4">
                          <div className="w-full h-[60vh] flex items-center justify-center bg-gray-50 rounded-lg border">
                            <div className="text-center">
                              <div className="icon-image text-6xl text-gray-600 mb-4 mx-auto"></div>
                              <p className="text-xl font-semibold text-gray-800 mb-2">ملف خريطة</p>
                              <p className="text-gray-600 mb-2">تم رفع الملف بنجاح</p>
                              <p className="text-sm text-gray-500 mb-4">
                                {fileName || 'ملف مرفوع'}
                              </p>
                              {dataUrl.startsWith('data:') && (
                                <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs inline-block">
                                  ملف محلي مرفوع
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="flex gap-3 justify-center">
                            <a 
                              href={dataUrl} 
                              download={fileName || `${selectedRegion.objectData.name}-map`}
                              className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all flex items-center gap-2"
                            >
                              <div className="icon-download text-xl"></div>
                              تنزيل الملف
                            </a>
                          </div>
                        </div>
                      );
                    }
                  })()
                ) : (
                  <p className="text-center text-gray-500 py-8">لم يتم إضافة خريطة لهذه المنطقة بعد</p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('MapsPage error:', error);
    return null;
  }
}