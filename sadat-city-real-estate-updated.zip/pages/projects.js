function ProjectsPage({ properties }) {
  try {
    const [filter, setFilter] = React.useState('all');
    
    const filteredProperties = properties.filter(prop => {
      if (filter === 'all') return true;
      return prop.objectData.type === filter;
    });

    return (
      <div className="py-8 md:py-16 bg-[var(--light-bg)]" data-name="projects-page" data-file="pages/projects.js">
        <div className="container mx-auto px-4">
          <h1 className="section-title text-2xl md:text-4xl">جميع المشاريع</h1>
          
          <div className="flex flex-wrap justify-center gap-2 md:gap-4 mb-6 md:mb-8">
            <button 
              onClick={() => setFilter('all')}
              className={`px-6 py-2 rounded-lg font-semibold ${filter === 'all' ? 'btn-primary' : 'bg-white'}`}
            >
              الكل
            </button>
            <button 
              onClick={() => setFilter('residential')}
              className={`px-6 py-2 rounded-lg font-semibold ${filter === 'residential' ? 'btn-primary' : 'bg-white'}`}
            >
              سكني
            </button>
            <button 
              onClick={() => setFilter('commercial')}
              className={`px-6 py-2 rounded-lg font-semibold ${filter === 'commercial' ? 'btn-primary' : 'bg-white'}`}
            >
              تجاري
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProperties.map(property => (
              <ProjectCard key={property.objectId} property={property} showDetails={true} />
            ))}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ProjectsPage error:', error);
    return null;
  }
}
