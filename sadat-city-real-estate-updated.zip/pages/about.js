function AboutPage() {
  try {
    return (
      <div className="py-8 md:py-16 bg-white" data-name="about-page" data-file="pages/about.js">
        <div className="container mx-auto px-4 max-w-4xl">
          <h1 className="section-title text-2xl md:text-4xl">من نحن</h1>
          
          <div className="bg-white rounded-xl shadow-lg p-4 md:p-8 mb-8">
            <p className="text-xl leading-relaxed mb-8 text-gray-700">
              <strong className="text-[var(--primary-color)] text-2xl">الجنرال للتسويق العقاري</strong> هي شركة رائدة في مجال التسويق العقاري بمدينة السادات، مصر. تأسست الشركة على يد نخبة من المتخصصين في المجال العقاري بهدف تقديم أفضل الحلول العقارية للعملاء.
            </p>
            
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-4 text-[var(--dark-color)] border-r-4 border-[var(--primary-color)] pr-4">المؤسسون</h2>
              <p className="text-lg leading-relaxed mb-4 text-gray-700">
                تفخر شركة الجنرال بأن تكون تحت قيادة اثنين من أبرز الخبراء في المجال العقاري:
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-gradient-to-br from-orange-50 to-white p-6 rounded-lg border-r-4 border-[var(--primary-color)]">
                  <h3 className="font-bold text-xl mb-2 text-[var(--primary-color)]">الكابتن سامح</h3>
                  <p className="text-gray-600">مؤسس مشارك وخبير استراتيجي في التسويق العقاري</p>
                </div>
                <div className="bg-gradient-to-br from-orange-50 to-white p-6 rounded-lg border-r-4 border-[var(--secondary-color)]">
                  <h3 className="font-bold text-xl mb-2 text-[var(--secondary-color)]">المهندس محمد زرزور</h3>
                  <p className="text-gray-600">مؤسس مشارك ومتخصص في التطوير العقاري</p>
                </div>
              </div>
            </div>
            
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-4 text-[var(--dark-color)] border-r-4 border-[var(--primary-color)] pr-4">رؤيتنا</h2>
              <p className="text-lg leading-relaxed text-gray-700 bg-gray-50 p-6 rounded-lg">
                نسعى لأن نكون الخيار الأول للباحثين عن العقارات في مدينة السادات من خلال تقديم خدمات تسويقية متميزة وحلول عقارية مبتكرة تلبي احتياجات عملائنا وتتجاوز توقعاتهم.
              </p>
            </div>
            
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-4 text-[var(--dark-color)] border-r-4 border-[var(--primary-color)] pr-4">خدماتنا</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="flex items-start gap-3 bg-gray-50 p-4 rounded-lg">
                  <div className="icon-check-circle text-xl text-green-600 mt-1"></div>
                  <span className="text-lg text-gray-700">تسويق العقارات السكنية والتجارية</span>
                </div>
                <div className="flex items-start gap-3 bg-gray-50 p-4 rounded-lg">
                  <div className="icon-check-circle text-xl text-green-600 mt-1"></div>
                  <span className="text-lg text-gray-700">استشارات عقارية متخصصة</span>
                </div>
                <div className="flex items-start gap-3 bg-gray-50 p-4 rounded-lg">
                  <div className="icon-check-circle text-xl text-green-600 mt-1"></div>
                  <span className="text-lg text-gray-700">إدارة المشاريع العقارية</span>
                </div>
                <div className="flex items-start gap-3 bg-gray-50 p-4 rounded-lg">
                  <div className="icon-check-circle text-xl text-green-600 mt-1"></div>
                  <span className="text-lg text-gray-700">خدمات ما بعد البيع</span>
                </div>
              </div>
            </div>
            
            <div>
              <h2 className="text-2xl font-bold mb-4 text-[var(--dark-color)] border-r-4 border-[var(--primary-color)] pr-4">لماذا الجنرال؟</h2>
              <p className="text-lg leading-relaxed text-gray-700 bg-gradient-to-l from-orange-50 to-white p-6 rounded-lg">
                نتميز بخبرتنا الواسعة في سوق العقارات بمدينة السادات، وفهمنا العميق لاحتياجات العملاء، والتزامنا بتقديم أعلى مستويات الخدمة والمصداقية في كل تعاملاتنا.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('AboutPage component error:', error);
    return null;
  }
}
