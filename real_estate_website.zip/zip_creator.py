import os
import zipfile
import shutil
from pathlib import Path

# Create zip file
zip_path = '/workspace/sadat-city-real-estate-updated.zip'

print("Creating updated zip file...")

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Core server file
    if os.path.exists('/workspace/hybrid_server.py'):
        zipf.write('/workspace/hybrid_server.py', 'hybrid_server.py')
        print("Added: hybrid_server.py")
    
    # Main HTML files
    for file in ['index.html', 'property-details.html']:
        if os.path.exists(f'/workspace/{file}'):
            zipf.write(f'/workspace/{file}', file)
            print(f"Added: {file}")
    
    # JavaScript files
    for file in ['app.js', 'property-details-app.js']:
        if os.path.exists(f'/workspace/{file}'):
            zipf.write(f'/workspace/{file}', file)
            print(f"Added: {file}")
    
    # Add directories recursively
    for dir_name in ['components', 'pages', 'utils', 'trickle']:
        dir_path = f'/workspace/{dir_name}'
        if os.path.exists(dir_path):
            for root, dirs, files in os.walk(dir_path):
                # Skip certain patterns
                if any(x in root for x in ['tmp', 'user_input', 'browser', 'extract']):
                    continue
                    
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = file_path.replace('/workspace/', '')
                    zipf.write(file_path, arcname)
                    print(f"Added: {arcname}")
    
    # Add cloudflared binary
    if os.path.exists('/workspace/cloudflared-new'):
        zipf.write('/workspace/cloudflared-new', 'cloudflared-new')
        print("Added: cloudflared-new")

# Check file size
if os.path.exists(zip_path):
    size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    print(f"\n✅ ZIP file created successfully!")
    print(f"   Path: {zip_path}")
    print(f"   Size: {size_mb:.2f} MB")
else:
    print("❌ Failed to create zip file")