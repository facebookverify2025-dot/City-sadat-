class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">حدث خطأ ما</h1>
            <p className="text-gray-600 mb-4">نعتذر، حدث خطأ غير متوقع</p>
            <button onClick={() => window.location.reload()} className="btn-primary">
              إعادة تحميل الصفحة
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  try {
    const [currentPage, setCurrentPage] = React.useState(() => {
      const hash = window.location.hash.substring(1);
      return hash === 'admin' ? 'admin' : 'home';
    });
    const [isAdmin, setIsAdmin] = React.useState(false);
    const [regions, setRegions] = React.useState([]);
    const [properties, setProperties] = React.useState([]);
    const [settings, setSettings] = React.useState({});
    const [theme, setTheme] = React.useState(localStorage.getItem('theme') || 'default');

    React.useEffect(() => {
      loadData();
      document.documentElement.setAttribute('data-theme', theme);
      
      // Listen for real-time updates
      if (window.trickleOnUpdate) {
        window.trickleOnUpdate('dataChange', (event) => {
          console.log('📡 Real-time data change detected:', event);
          // Reload data when real-time changes occur
          setTimeout(loadData, 100);
        });
        
        window.trickleOnUpdate('connection', (event) => {
          console.log('🔗 Real-time connection status:', event);
        });
      }
      
      const handleHashChange = () => {
        const hash = window.location.hash.substring(1);
        if (hash === 'admin') {
          setCurrentPage('admin');
        }
      };
      
      window.addEventListener('hashchange', handleHashChange);
      return () => {
        window.removeEventListener('hashchange', handleHashChange);
        // Clean up real-time listeners
        if (window.trickleOffUpdate) {
          window.trickleOffUpdate('dataChange');
          window.trickleOffUpdate('connection');
        }
      };
    }, []);

    React.useEffect(() => {
      document.documentElement.setAttribute('data-theme', theme);
      localStorage.setItem('theme', theme);
    }, [theme]);

    const loadData = async () => {
      try {
        const [regionsData, propertiesData, settingsData] = await Promise.all([
          Database.getRegions(),
          Database.getProperties(),
          Database.getSettings()
        ]);
        setRegions(regionsData);
        setProperties(propertiesData);
        setSettings(settingsData);
      } catch (error) {
        console.error('Load data error:', error);
      }
    };

    const handleNavigate = (page) => {
      if (page === 'admin') {
        window.location.hash = 'admin';
      } else {
        window.location.hash = '';
      }
      setCurrentPage(page);
    };

    return (
      <div data-name="app" data-file="app.js">
        <ThemeSwitcher currentTheme={theme} onThemeChange={setTheme} />
        <Header currentPage={currentPage} onNavigate={handleNavigate} isAdmin={isAdmin} />
        
        {currentPage === 'home' && <Hero onNavigate={handleNavigate} heroImageUrl={settings.objectData?.heroImageUrl} />}
        
        {currentPage === 'home' && (
          <div className="py-8 sm:py-12 md:py-16 bg-[var(--light-bg)]">
            <div className="container mx-auto px-4">
              <h2 className="section-title text-2xl sm:text-3xl md:text-4xl mb-6 sm:mb-8">مشاريعنا المتميزة</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {properties.slice(0, 6).map(property => (
                  <ProjectCard key={property.objectId} property={property} onNavigate={handleNavigate} showDetails={true} />
                ))}
              </div>
            </div>
          </div>
        )}

        {currentPage === 'about' && <AboutPage />}
        {currentPage === 'projects' && <ProjectsPage properties={properties} />}
        {currentPage === 'maps' && <MapsPage regions={regions} />}
        {currentPage === 'contact' && <ContactPage settings={settings} />}
        {currentPage === 'admin' && <AdminPanel onLogin={setIsAdmin} onNavigate={handleNavigate} onUpdate={loadData} />}

        <Footer settings={settings} onNavigate={handleNavigate} />
      </div>
    );
  } catch (error) {
    console.error('App component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);