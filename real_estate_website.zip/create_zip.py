#!/usr/bin/env python3
"""
Create updated zip file for the real estate application
"""

import os
import zipfile
import shutil
from pathlib import Path

def create_updated_zip():
    """Create a zip file with all updated application files"""
    
    # Define the files and directories to include
    files_to_include = [
        'hybrid_server.py',
        'index.html', 
        'app.js',
        'property-details.html',
        'property-details-app.js'
    ]
    
    dirs_to_include = [
        'components',
        'pages', 
        'utils',
        'trickle'
    ]
    
    # Individual files
    individual_files = [
        'cloudflared-new'
    ]
    
    # Files and dirs to exclude
    excluded_patterns = [
        'tmp',
        'user_input_files', 
        'browser',
        'extract',
        'sadat-city-real-estate.zip',
        'workspace.json',
        'realtime_server.py'
    ]
    
    zip_path = '/workspace/sadat-city-real-estate-updated.zip'
    
    print("Creating updated zip file...")
    print(f"Output: {zip_path}")
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Add individual files
        for file in files_to_include:
            file_path = f'/workspace/{file}'
            if os.path.exists(file_path):
                zipf.write(file_path, file)
                print(f"Added: {file}")
            else:
                print(f"Warning: {file} not found")
        
        # Add individual files (like cloudflared)
        for file in individual_files:
            file_path = f'/workspace/{file}'
            if os.path.exists(file_path):
                zipf.write(file_path, file)
                print(f"Added: {file}")
            else:
                print(f"Warning: {file} not found")
        
        # Add directories
        for dir_name in dirs_to_include:
            dir_path = f'/workspace/{dir_name}'
            if os.path.exists(dir_path):
                for root, dirs, files in os.walk(dir_path):
                    # Skip excluded directories
                    if any(pattern in root for pattern in excluded_patterns):
                        continue
                        
                    for file in files:
                        file_path = os.path.join(root, file)
                        # Calculate relative path for zip
                        arcname = file_path.replace('/workspace/', '')
                        zipf.write(file_path, arcname)
                        print(f"Added: {arcname}")
            else:
                print(f"Warning: {dir_name} directory not found")
    
    # Get zip file size
    zip_size = os.path.getsize(zip_path) / (1024 * 1024)  # MB
    print(f"\n✅ Zip file created successfully!")
    print(f"   File: {zip_path}")
    print(f"   Size: {zip_size:.2f} MB")
    
    return zip_path

if __name__ == '__main__':
    create_updated_zip()