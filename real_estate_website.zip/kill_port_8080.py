#!/usr/bin/env python3
import os
import signal
import time

# Try to find and kill any process using port 8080
def find_process_on_port(port):
    """Find process using the specified port"""
    try:
        # Read /proc/net/tcp to find processes
        with open('/proc/net/tcp', 'r') as f:
            content = f.read()
            
        lines = content.strip().split('\n')[1:]  # Skip header
        for line in lines:
            parts = line.split()
            if len(parts) >= 4:
                local_address = parts[1]
                if f':{port:04x}' in local_address.upper():
                    inode = parts[9]
                    print(f"Found connection on port {port}, inode: {inode}")
                    
                    # Find process using this inode
                    try:
                        for pid in os.listdir('/proc'):
                            if pid.isdigit():
                                try:
                                    fd_dir = f'/proc/{pid}/fd'
                                    for fd in os.listdir(fd_dir):
                                        try:
                                            link_target = os.readlink(f'{fd_dir}/{fd}')
                                            if f'socket:[{inode}]' in link_target:
                                                return int(pid)
                                        except:
                                            continue
                                except:
                                    continue
                    except:
                        pass
        return None
    except Exception as e:
        print(f"Error finding process: {e}")
        return None

# Main execution
port = 8080
print(f"Searching for process using port {port}...")

pid = find_process_on_port(port)
if pid:
    print(f"Found process PID {pid} using port {port}")
    try:
        os.kill(pid, signal.SIGTERM)
        print(f"✅ Sent SIGTERM to process {pid}")
        
        # Wait a moment and check if it's still running
        time.sleep(2)
        try:
            os.kill(pid, 0)  # Check if process still exists
            print(f"Process {pid} still running, sending SIGKILL...")
            os.kill(pid, signal.SIGKILL)
            print(f"✅ Sent SIGKILL to process {pid}")
        except:
            print(f"✅ Process {pid} terminated successfully")
            
    except Exception as e:
        print(f"❌ Failed to kill process {pid}: {e}")
else:
    print(f"No process found using port {port}")

print("Cleanup completed")