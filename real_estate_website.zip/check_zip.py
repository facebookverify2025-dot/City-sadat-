import zipfile
import os

# Check the created zip file
zip_path = '/workspace/sadat-city-real-estate-updated.zip'

print("🔍 Checking ZIP file contents...")
print("=" * 50)

if os.path.exists(zip_path):
    # Get file size
    size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    print(f"📁 File: {zip_path}")
    print(f"📊 Size: {size_mb:.2f} MB")
    print("=" * 50)
    
    # List contents
    with zipfile.ZipFile(zip_path, 'r') as zipf:
        file_list = zipf.namelist()
        print(f"📋 Total files: {len(file_list)}")
        print("\n📄 File list:")
        for i, file in enumerate(sorted(file_list), 1):
            print(f"   {i:2d}. {file}")
    
    print("=" * 50)
    print("✅ ZIP file is ready for download!")
    
    # Check for key files
    key_files = ['hybrid_server.py', 'index.html', 'utils/trickle.js']
    print("\n🔑 Key files verification:")
    for key_file in key_files:
        if key_file in file_list:
            print(f"   ✅ {key_file} - Present")
        else:
            print(f"   ❌ {key_file} - Missing")
            
else:
    print("❌ ZIP file not found!")