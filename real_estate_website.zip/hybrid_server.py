#!/usr/bin/env python3
"""
Hybrid Web + Real-time Server
Serves static files and provides real-time updates
"""

import json
import time
import os
from http.server import HTTPServer, SimpleHTTPRequestHandler
import threading
import urllib.parse
from datetime import datetime

class HybridHandler(SimpleHTTPRequestHandler):
    clients = []
    
    def __init__(self, *args, **kwargs):
        # Set the working directory to workspace
        super().__init__(*args, directory='/workspace', **kwargs)
    
    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()
    
    def send_cors_headers(self):
        """Send CORS headers"""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, X-API-Key')
    
    def do_GET(self):
        """Handle GET requests"""
        path = self.path.split('?')[0]
        
        # Handle real-time endpoints
        if path == '/events':
            self.handle_sse()
        elif path == '/health':
            self.handle_health()
        else:
            # Handle static files
            super().do_GET()
    
    def do_POST(self):
        """Handle POST requests"""
        path = self.path.split('?')[0]
        
        if path == '/broadcast':
            self.handle_broadcast()
        else:
            self.send_error(404, "Not Found")
    
    def handle_health(self):
        """Health check endpoint"""
        self.send_response(200)
        self.send_cors_headers()
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        
        response = {
            "status": "ok",
            "timestamp": datetime.now().isoformat(),
            "connected_clients": len(self.clients),
            "server": "hybrid"
        }
        
        self.wfile.write(json.dumps(response).encode())
    
    def handle_sse(self):
        """Handle Server-Sent Events connection"""
        # Set headers for SSE
        self.send_response(200)
        self.send_cors_headers()
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Cache-Control', 'no-cache')
        self.send_header('Connection', 'keep-alive')
        self.end_headers()
        
        # Add client to connected clients list
        client = {
            'id': int(time.time() * 1000),
            'request': self,
            'path': self.path
        }
        self.clients.append(client)
        
        print(f"New SSE client connected. Total clients: {len(self.clients)}")
        
        # Send initial connection message
        try:
            self.send_sse_message('connected', {
                'client_id': client['id'],
                'message': 'Connected to real-time updates',
                'timestamp': datetime.now().isoformat()
            })
        except:
            pass
        
        # Keep connection alive and handle client
        try:
            while True:
                # Send heartbeat every 30 seconds
                time.sleep(30)
                self.send_sse_message('heartbeat', {
                    'timestamp': datetime.now().isoformat()
                })
                
        except Exception as e:
            print(f"SSE Client {client['id']} disconnected: {e}")
        finally:
            # Remove client when disconnected
            if client in self.clients:
                self.clients.remove(client)
            print(f"SSE Client {client['id']} removed. Total clients: {len(self.clients)}")
    
    def handle_broadcast(self):
        """Handle broadcast requests from admin or data updates"""
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            
            # Parse the request
            data = json.loads(post_data.decode('utf-8'))
            
            # Broadcast to all connected clients
            self.broadcast_update(data)
            
            # Send success response
            self.send_response(200)
            self.send_cors_headers()
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            
            response = {
                "status": "success",
                "broadcasted": len(self.clients),
                "timestamp": datetime.now().isoformat()
            }
            
            self.wfile.write(json.dumps(response).encode())
            
            print(f"Broadcasted to {len(self.clients)} clients: {data.get('type', 'unknown')}")
            
        except Exception as e:
            print(f"Broadcast error: {e}")
            self.send_error(500, f"Broadcast failed: {str(e)}")
    
    def send_sse_message(self, event_type, data):
        """Send SSE message to this client"""
        message = f"event: {event_type}\n"
        message += f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
        
        try:
            self.wfile.write(message.encode('utf-8'))
            self.wfile.flush()
        except Exception as e:
            print(f"Failed to send message to client: {e}")
            raise
    
    def broadcast_update(self, data):
        """Broadcast update to all connected clients"""
        disconnected_clients = []
        
        for client in self.clients:
            try:
                self.send_sse_message('update', data)
            except Exception as e:
                print(f"Failed to send to client {client['id']}: {e}")
                disconnected_clients.append(client)
        
        # Remove disconnected clients
        for client in disconnected_clients:
            if client in self.clients:
                self.clients.remove(client)
    
    def log_message(self, format, *args):
        """Custom log message with timestamp"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{timestamp}] {format % args}")

def start_hybrid_server():
    """Start the hybrid web + real-time server"""
    port = 3000
    
    try:
        server = HTTPServer(('0.0.0.0', port), HybridHandler)
        print(f"🚀 Hybrid server started on port {port}")
        print(f"   Website: http://localhost:{port}/")
        print(f"   Real-time SSE: http://localhost:{port}/events")
        print(f"   Health check: http://localhost:{port}/health")
        print(f"   Broadcast endpoint: http://localhost:{port}/broadcast")
        
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\n🛑 Hybrid server stopped")
            server.shutdown()
            
    except OSError as e:
        if "Address already in use" in str(e):
            print(f"❌ Failed to start server on port {port}: {e}")
            print(f"Port {port} is already in use by another application")
            print("Please stop the other application or use a different port")
        else:
            print(f"❌ Failed to start server: {e}")

if __name__ == '__main__':
    start_hybrid_server()