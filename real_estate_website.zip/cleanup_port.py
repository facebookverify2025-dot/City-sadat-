#!/usr/bin/env python3
import os
import signal
import subprocess

# Find and kill process using port 8080
try:
    # Try to find process using lsof
    result = subprocess.run(['lsof', '-i', ':8080'], capture_output=True, text=True)
    if result.returncode == 0:
        lines = result.stdout.strip().split('\n')
        if len(lines) > 1:
            # Skip header line
            for line in lines[1:]:
                parts = line.split()
                if len(parts) >= 2:
                    pid = parts[1]
                    print(f"Found process using port 8080: PID {pid}")
                    try:
                        os.kill(int(pid), signal.SIGTERM)
                        print(f"✅ Killed process {pid}")
                    except Exception as e:
                        print(f"❌ Failed to kill process {pid}: {e}")
                        # Try force kill
                        try:
                            os.kill(int(pid), signal.SIGKILL)
                            print(f"✅ Force killed process {pid}")
                        except Exception as e2:
                            print(f"❌ Force kill failed: {e2}")
        else:
            print("lsof found no processes on port 8080")
    else:
        print("lsof not available or no process found")
        
    # Try alternative method using netstat
    result = subprocess.run(['netstat', '-tlnp'], capture_output=True, text=True)
    if result.returncode == 0:
        lines = result.stdout.split('\n')
        for line in lines:
            if ':8080' in line and 'LISTEN' in line:
                print(f"Netstat found: {line}")
                # Extract PID from netstat output
                parts = line.split()
                if len(parts) >= 7:
                    pid_info = parts[6]
                    if '/' in pid_info:
                        pid = pid_info.split('/')[0]
                        try:
                            os.kill(int(pid), signal.SIGTERM)
                            print(f"✅ Killed process {pid} from netstat")
                        except Exception as e:
                            print(f"❌ Failed to kill process {pid}: {e}")
    
    print("Port cleanup completed")
    
except Exception as e:
    print(f"Error: {e}")