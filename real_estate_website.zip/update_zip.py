import zipfile
import os

# Update the existing zip file with README
zip_path = '/workspace/sadat-city-real-estate-updated.zip'
readme_path = '/workspace/README.md'

print("📝 Adding README to ZIP file...")

if os.path.exists(readme_path):
    with zipfile.ZipFile(zip_path, 'a', zipfile.ZIP_DEFLATED) as zipf:
        zipf.write(readme_path, 'README.md')
        print("✅ README.md added successfully")
    
    # Check final size
    size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    print(f"📊 Final ZIP size: {size_mb:.2f} MB")
else:
    print("❌ README.md not found")

print("\n🎉 Final ZIP package ready!")
print(f"📁 File: {zip_path}")
print("\n📋 Package includes:")
print("   • Complete real estate application")
print("   • Real-time server (hybrid_server.py)")
print("   • All React components and pages")
print("   • Database utilities (Trickle.js)")
print("   • Cloudflared tunnel tool")
print("   • Complete documentation (README.md)")
print("\n🚀 Ready to deploy!")