#!/usr/bin/env python3
import socket
import psutil
import sys

def check_port(port):
    """Check if a port is in use and try to identify the process"""
    print(f"Checking port {port}...")
    
    # Check if port is in use
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            result = s.connect_ex(('localhost', port))
            if result == 0:
                print(f"❌ Port {port} is already in use")
                
                # Try to find the process using this port
                try:
                    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                        try:
                            connections = proc.connections(kind='inet')
                            for conn in connections:
                                if conn.laddr.port == port:
                                    print(f"Process using port {port}: PID {proc.info['pid']}, Name: {proc.info['name']}")
                                    print(f"Command: {' '.join(proc.info['cmdline'])}")
                                    return False
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            continue
                except:
                    print("Could not identify process using the port")
                return False
            else:
                print(f"✅ Port {port} is available")
                return True
                
    except Exception as e:
        print(f"Error checking port: {e}")
        return False

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    available = check_port(port)
    if available:
        print("Port is available for use")
    else:
        print("Port is in use - cannot start server")